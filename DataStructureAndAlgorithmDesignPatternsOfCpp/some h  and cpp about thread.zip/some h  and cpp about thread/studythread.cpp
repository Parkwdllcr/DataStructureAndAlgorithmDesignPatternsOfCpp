﻿// testptrchar.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "CThread.h"
#include <string>


//可以设置成毫秒之类的
void mySleep(int imicroseconds)
{

	//std::this_thread::sleep_for(std::chrono::duration<double>(s));
	std::this_thread::sleep_for(std::chrono::microseconds(imicroseconds));
}

class MyThread : public CThread
{
protected:
	virtual void process() override
	{
		std::cout << "do my something" << std::endl;
		mySleep(1000);
	}
};

int main()
{
	MyThread thread;

	std::cout << "start thread" << std::endl;
	thread.start();
	std::cout << "thread state:" << thread.state() << std::endl;
	mySleep(3);

	std::cout << "pause thread" << std::endl;
	thread.pause();
	std::cout << "thread state:" << thread.state() << std::endl;
	mySleep(3);

	std::cout << "resume thread" << std::endl;
	thread.resume();
	std::cout << "thread state:" << thread.state() << std::endl;
	mySleep(3);

	std::cout << "stop thread" << std::endl;
	thread.stop();
	std::cout << "thread state:" << thread.state() << std::endl;
	mySleep(3);

	system("pause");
}


//
//#include <iostream>
//#include <time.h>
//#include "ListAndMap/CStudyStlManager.h"
//#include "MulThread/thread_mutex.h"
//#include "MulThread/Actor.h"
//#include "MulThread/thread_semaphore.h"
//
//#include <iostream>
//int main()
//{
//	double dbStartTime, dbEndTime, dbTialTime;
//	bool bShutDown = true;
//	dbStartTime = (clock() / CLOCKS_PER_SEC);
//	CStudyStlManager* pStlManager = new CStudyStlManager();
//	pStlManager->Initialize();
//
//	while (bShutDown)
//	{
//		dbEndTime = (clock() / CLOCKS_PER_SEC);
//		dbTialTime = (dbEndTime - dbStartTime);
//		if (dbTialTime > 6)
//		{
//			bShutDown = false;
//		}
//	}
//	pStlManager->Shutdown();
//	while (pStlManager->getListSize() > 0);
//	if (nullptr != pStlManager && pStlManager->getListSize() == 0)
//	{
//		delete pStlManager;
//		pStlManager = nullptr;
//	}
//
//	return 1;
//}


