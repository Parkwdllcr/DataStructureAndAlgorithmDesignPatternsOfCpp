#pragma once
#include<string>

class CStudyCPrimerPlus;

class CStudyString
{
public:
	CStudyString(const char* pConstChar) :m_strInitFirst(pConstChar),m_pPubicClass(nullptr) {}
	~CStudyString();
public:
	void Inital();
protected:
private:
	std::string  m_strInitFirst;
	CStudyCPrimerPlus*  m_pPubicClass;
};
