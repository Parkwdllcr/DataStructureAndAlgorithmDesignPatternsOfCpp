#include "thread.h"
#
#if defined (OS_WIN32)
#  include <process.h>
#endif

#if defined (OS_WIN32)

Thread::Thread()
: _handle(NULL)
, _tid(0)
{
}

unsigned _stdcall _ThreadEntry(void* param)
{
	ThreadStart* start = static_cast<ThreadStart*>(param);
	int ret = (*start)(); // �����������̺߳���
	MemPool::Deallocate(param);
	return ret;
}

Thread::~Thread()
{
	if (_handle != NULL)
		::CloseHandle(_handle);
}

bool Thread::Start(const ThreadStart& threadStart)
{
	if (_handle != NULL)
		::CloseHandle(_handle);

	ThreadStart* param =
		static_cast<ThreadStart*>(MemPool::Allocate(sizeof(ThreadStart)));
	assert(param != NULL);
	if (param == NULL)
		return false;

	*param = threadStart; // ����ֵ
	_handle = (HANDLE)::_beginthreadex(NULL, 0, &_ThreadEntry, param, 0, &_tid);
	assert(_handle != NULL);
	if (_handle == NULL)
	{
		MemPool::Deallocate(param);
		return false;
	}

	return true;
}

bool Thread::Join()
{
	if (NULL == _handle)
		return false;

	if (_tid == ::GetCurrentThreadId()) // ��ֹ�߳��������ô˺����������
		return false;

	if (WAIT_OBJECT_0 != ::WaitForSingleObject(_handle, INFINITE))
		return false;

	::CloseHandle(_handle);
	_handle = NULL;
	_tid = 0;
	return true;
}

void Thread::Sleep(const Time& t)
{
	for (int i = 0; i < 5; ++i)
	{
		int milliseconds;
		ToDuration(t, milliseconds);
		::Sleep(milliseconds);

		Time cur;
		Time::Now(cur);
		if (Time::Compare(t, cur) <= 0)
			return;
	}
}

#elif defined(OS_LINUX)

Thread::Thread()
: _created(false)
{
}

void* _ThreadEntry(void* param)
{
	ThreadStart* start = static_cast<ThreadStart*>(param);
	int ret = (*start)(); // �����������̺߳���
	MemPool::Deallocate(param);
	return NULL;
}

Thread::~Thread()
{
	if (_created)
		::pthread_detach(_handle);
}

bool Thread::Start(const ThreadStart& threadStart)
{
	if (_created)
		::pthread_detach(_handle);
	_created = false;

	ThreadStart* param = 
		static_cast<ThreadStart*>(MemPool::Allocate(sizeof(ThreadStart)));
	assert(param != NULL);
	if (param == NULL)
		return false;

	*param = threadStart; // ����ֵ
	int ret = ::pthread_create(&_handle, NULL, &_thread_entry, param);
	assert(ret == 0);
	if (ret != 0)
	{
		MemPool::Deallocate(param);
		return false;
	}

	_created = true;
	return true;
}

bool Thread::Join()
{
	if (!_created)
		return false;

	pthread_t curthr = ::pthread_self();
	if (pthread_equal(curthr, _handle))
		return false;

	pthread_join(_handle, 0);
	_created = false;
	return true;
}

void Thread::Sleep(const Time& xt)
{
	for (int i = 0; i < 5; ++i)
	{
		timespec ts;
		to_timespec_duration(xt, ts);
		int res = 0;
		res = ::pthread_delay_np(&ts);
		assert(res == 0);

		xtime cur;
		cur.Now();
		if (XTimeCompare(xt, cur) <= 0)
			return;
	}
}

#endif
