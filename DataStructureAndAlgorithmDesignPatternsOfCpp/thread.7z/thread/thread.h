#ifndef THREAD_H
#define THREAD_H

class ThreadStart;

// �߳��࣬�����������߳�
class Thread : private NonCopyable
{
public:
	Thread();
	~Thread();

	// @summary �����߳�
	// @param fun �̺߳�����֧��int(void*)��int(class::*)()��������
	bool Start(const ThreadStart& threadStart);
	// �ȴ��߳̽���
	bool Join();

	// �߳����ߵ�xtʱ���
	static void Sleep(const Time& t);

private:
#if defined (OS_WIN32)
	unsigned _tid;
	HANDLE _handle;
#elif defined(OS_LINUX)
	pthread_t _handle;
	bool _created;
#endif
};

// ThreadStart helper
template<typename dst_type, typename src_type>
	dst_type union_cast(src_type src)
{
	union
	{
		src_type src;
		dst_type dst;
	} u = {src};
	return u.dst;
}

// �̷߳º���
class ThreadStart
{
public:
	// ȫ�ֺ����߳�
	ThreadStart(int (*proc)(void*), void* param)
	{
		_threadType = TYPE_PROC;
		_threadProc = proc;
		_threadParam = param;
	}

	// �����߳�
	template<typename Type>
		ThreadStart(Type* object, int (Type::*method)(void))
	{
		_threadType = TYPE_METHOD;
		_methodObj = static_cast<void*>(object);
		_methodStor = union_cast<MethodStorage>(method);
		_methodProc = &MethodInvoker<Type>;
	}

	unsigned operator()()
	{
		if (_threadType == TYPE_PROC)
			return _threadProc(_threadParam);
		else
			return _methodProc(this);
	}

private:
	template<typename Type>
		static int MethodInvoker(ThreadStart* threadStart)
	{
		typedef int (Type::*MethodType)(void);
		Type* object = static_cast<Type*>(threadStart->_methodObj);
		MethodType method = union_cast<MethodType>(threadStart->_methodStor);
		return (object->*method)();
	}

private:
	enum THREAD_TYPE{ TYPE_PROC, TYPE_METHOD };
	struct MethodStorage { char storage[sizeof(void*) * 3]; }; // ������̳�
	typedef int (*ThreadProc)(void*);
	typedef int (*MethodProc)(ThreadStart*);

	THREAD_TYPE		_threadType;
	ThreadProc		_threadProc;
	void*			_threadParam;

	MethodStorage	_methodStor;
	MethodProc		_methodProc;
	void*			_methodObj;
};

/*
int ThreadFunction(void* param)
{
	cout << "ThreadFunction " << (int)param << endl; 
	return 0;
}

class Test
{
public:
	int ThreadMethod()
	{
		cout << "ThreadMethod" << endl; 
		return 0;
	}

};

int main()
{
	Thread t1;
	t1.Start(ThreadStart(&ThreadFunction, (void*)1));
	t1.Join();

	Test test;
	Thread t2;
	t2.Start(ThreadStart(&test, &Test::ThreadMethod));
	t2.Join();

	cout << "OK" << endl;
	cin.get();
	return 0;
}
*/

#endif // THREAD_H

