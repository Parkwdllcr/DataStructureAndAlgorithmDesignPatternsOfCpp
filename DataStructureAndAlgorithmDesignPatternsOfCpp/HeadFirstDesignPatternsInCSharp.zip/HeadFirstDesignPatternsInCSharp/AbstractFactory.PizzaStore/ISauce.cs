using System;

namespace HeadFirstDesignPatterns.AbstractFactory.PizzaStore
{
	/// <summary>
	/// Summary description for ISauce.
	/// </summary>
	public interface ISauce 
	{
		 string toString();
	}
}
